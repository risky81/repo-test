"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Upload, Calendar, FileText } from "lucide-react"

export default function MemoryUpload() {
  const [isOpen, setIsOpen] = useState(false)
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split("T")[0],
    caption: "",
    image: null as File | null,
  })

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFormData({ ...formData, image: e.target.files[0] })
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Memory uploaded:", formData)
    setFormData({
      date: new Date().toISOString().split("T")[0],
      caption: "",
      image: null,
    })
    setIsOpen(false)
  }

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 z-40 px-6 py-4 bg-gradient-to-br from-primary to-accent text-accent-foreground rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 flex items-center gap-2 font-semibold"
      >
        <Upload size={20} />
        <span className="hidden sm:inline">Tambah Kenangan</span>
      </button>

      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
          onClick={() => setIsOpen(false)}
        >
          <Card className="w-full max-w-md bg-gradient-to-br from-background to-secondary">
            <div className="p-6">
              <button
                onClick={() => setIsOpen(false)}
                className="absolute top-4 right-4 text-foreground hover:text-primary transition-colors"
              >
                ✕
              </button>

              <h2 className="text-2xl font-bold text-primary mb-2">Simpan Kenangan</h2>
              <p className="text-muted-foreground mb-6">Bagikan momen spesial Anda dengan deskripsi yang bermakna</p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div
                  onClick={() => document.getElementById("imageInput")?.click()}
                  className="border-2 border-dashed border-accent/50 rounded-xl p-8 text-center cursor-pointer hover:border-accent transition-colors bg-accent/5"
                >
                  <input id="imageInput" type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
                  <Upload className="mx-auto mb-3 text-accent" size={32} />
                  <p className="font-semibold text-foreground mb-1">
                    {formData.image ? formData.image.name : "Klik untuk upload foto"}
                  </p>
                  <p className="text-xs text-muted-foreground">atau drag and drop</p>
                </div>

                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-2">
                    <Calendar size={16} className="text-primary" />
                    Tanggal Kenangan
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-2">
                    <FileText size={16} className="text-primary" />
                    Deskripsi Kenangan
                  </label>
                  <textarea
                    value={formData.caption}
                    onChange={(e) => setFormData({ ...formData, caption: e.target.value })}
                    placeholder="Ceritakan tentang kenangan spesial ini..."
                    className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none h-24"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsOpen(false)}
                    className="flex-1 px-4 py-2 rounded-lg border border-border text-foreground hover:bg-secondary transition-colors font-medium"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={!formData.image || !formData.caption}
                    className="flex-1 px-4 py-2 bg-gradient-to-br from-primary to-accent text-accent-foreground rounded-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                  >
                    Simpan Kenangan
                  </button>
                </div>
              </form>
            </div>
          </Card>
        </div>
      )}
    </>
  )
}
