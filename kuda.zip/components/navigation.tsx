"use client"

import { useState, useEffect } from "react"

interface NavigationProps {
  activeSection: string
  onNavigate: (section: string) => void
}

export default function Navigation({ activeSection, onNavigate }: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? "bg-background/95 backdrop-blur shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="max-w-5xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-primary cursor-pointer" onClick={() => onNavigate("home")}>
            Portfolio
          </h1>

          <div className="flex gap-6 sm:gap-8 items-center">
            {["Beranda", "Tentang", "Galeri"].map((item, index) => {
              const sectionId = ["home", "about", "gallery"][index]
              return (
                <button
                  key={sectionId}
                  onClick={() => onNavigate(sectionId)}
                  className={`text-sm font-medium transition-colors ${
                    activeSection === sectionId ? "text-primary" : "text-foreground/60 hover:text-foreground"
                  }`}
                >
                  {item}
                </button>
              )
            })}
          </div>
        </div>
      </div>
    </nav>
  )
}
