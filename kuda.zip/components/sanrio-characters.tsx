"use client"

export default function SanrioCharacters() {
  const characters = [
    {
      id: 1,
      name: "Hello Kitty",
      emoji: "🐱",
      position: "top-20 left-10",
      animation: "animate-float",
    },
    {
      id: 2,
      name: "Badtz Maru",
      emoji: "🐧",
      position: "bottom-20 right-10",
      animation: "animate-bounce-slow",
    },
    {
      id: 3,
      name: "My Melody",
      emoji: "🐰",
      position: "top-1/3 right-20",
      animation: "animate-sway",
    },
    {
      id: 4,
      name: "Gudetama",
      emoji: "🥚",
      position: "bottom-1/3 left-20",
      animation: "animate-bounce-slow",
    },
  ]

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {characters.map((char) => (
        <div
          key={char.id}
          className={`absolute ${char.position} text-6xl ${char.animation}`}
          style={{ opacity: 0.3 }}
          title={char.name}
        >
          {char.emoji}
        </div>
      ))}

      {/* Decorative elements */}
      <div className="absolute top-1/4 left-1/4 text-4xl animate-sway opacity-20">✨</div>
      <div className="absolute bottom-1/4 right-1/4 text-4xl animate-float opacity-20">✨</div>
      <div className="absolute top-1/2 right-1/3 text-3xl animate-bounce-slow opacity-15">♡</div>
    </div>
  )
}
