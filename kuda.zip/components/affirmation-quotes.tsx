"use client"

import { useState, useEffect } from "react"
import { Heart } from "lucide-react"

const affirmations = [
  "Kamu cantik seperti hari-hari bahagia",
  "Setiap kenangan mu adalah karya seni",
  "Kamu layak untuk dikenang selamanya",
  "Senyummu membuat dunia lebih indah",
  "Kehidupanmu penuh warna dan makna",
  "Kamu spesial hanya dengan menjadi dirimu sendiri",
  "Setiap momen bersamamu adalah hadiah",
  "Kamu adalah pemilik cerita yang indah",
  "Beauty is in your memories",
  "Kamu patut bangga dengan semua momen mu",
]

export default function AffirmationQuotes() {
  const [currentAffirmation, setCurrentAffirmation] = useState(0)
  const [isFlipped, setIsFlipped] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentAffirmation((prev) => (prev + 1) % affirmations.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="py-12 px-4">
      <div className="max-w-md mx-auto">
        {/* Card container */}
        <div className="relative h-64 cursor-pointer perspective" onClick={() => setIsFlipped(!isFlipped)}>
          {/* Animated card */}
          <div
            className={`relative w-full h-full transition-transform duration-500 ${
              isFlipped ? "[transform:rotateY(180deg)]" : ""
            }`}
            style={{
              transformStyle: "preserve-3d",
              transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
            }}
          >
            {/* Front of card */}
            <div
              className="absolute w-full h-full bg-gradient-to-br from-primary/20 via-secondary/30 to-accent/20 rounded-2xl p-8 flex flex-col items-center justify-center border-2 border-primary/40 backdrop-blur-sm"
              style={{ backfaceVisibility: "hidden" }}
            >
              <Heart className="w-12 h-12 text-primary mb-4 animate-pulse" />
              <p className="text-center text-xl font-semibold text-primary">Klik untuk membuka</p>
              <p className="text-center text-sm text-muted-foreground mt-2">Affirmation untuk Hari Mu</p>
            </div>

            {/* Back of card */}
            <div
              className="absolute w-full h-full bg-gradient-to-br from-secondary via-primary/10 to-accent rounded-2xl p-8 flex flex-col items-center justify-center border-2 border-primary/40 backdrop-blur-sm"
              style={{
                backfaceVisibility: "hidden",
                transform: "rotateY(180deg)",
              }}
            >
              <p className="text-center text-2xl font-bold text-primary leading-relaxed">
                {affirmations[currentAffirmation]}
              </p>
              <div className="flex gap-2 justify-center mt-6">
                {affirmations.map((_, idx) => (
                  <div
                    key={idx}
                    className={`h-2 rounded-full transition-all ${
                      idx === currentAffirmation ? "bg-primary w-6" : "bg-primary/30 w-2"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Floating hearts animation */}
        <div className="mt-8 flex justify-center gap-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="text-2xl animate-bounce" style={{ animationDelay: `${i * 0.2}s` }}>
              ✨
            </div>
          ))}
        </div>

        {/* Navigation text */}
        <p className="text-center text-sm text-muted-foreground mt-6">
          Klik kartu untuk membaca affirmation setiap hari 💕
        </p>
      </div>
    </section>
  )
}
