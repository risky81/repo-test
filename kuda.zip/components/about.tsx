export default function About() {
  return (
    <section className="py-20 px-4 bg-background">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl sm:text-5xl font-bold text-foreground mb-12 text-balance">Tentang Saya</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="md:col-span-1">
            <div className="sticky top-24">
              <img
                src="/personal-photo.jpg"
                alt="Foto pribadi"
                className="w-full rounded-lg shadow-lg object-cover"
              />
            </div>
          </div>

          <div className="md:col-span-2 space-y-6">
            <div>
              <h3 className="text-2xl font-semibold text-primary mb-3">Kisah Saya</h3>
              <p className="text-foreground/70 leading-relaxed mb-4">
                Halo! Saya adalah seorang individu yang passionate tentang hidup dan menciptakan kenangan indah.
                Perjalanan hidup saya dipenuhi dengan berbagai pengalaman unik yang telah membentuk siapa saya hari ini.
              </p>
              <p className="text-foreground/70 leading-relaxed mb-4">
                Saya percaya pada kekuatan cerita visual dan bagaimana sebuah foto dapat menangkap esensi dari sebuah
                momen. Setiap gambar di galeri saya mewakili bagian dari perjalanan saya yang ingin saya bagikan dengan
                Anda.
              </p>
            </div>

            <div>
              <h3 className="text-2xl font-semibold text-primary mb-3">Passion & Minat</h3>
              <div className="grid grid-cols-2 gap-4">
                {["Fotografi", "Traveling", "Kreativitas", "Storytelling", "Seni", "Eksplorasi"].map((item) => (
                  <div
                    key={item}
                    className="px-4 py-2 bg-secondary/50 rounded-lg border border-primary/20 text-foreground font-medium"
                  >
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-semibold text-primary mb-3">Nilai-nilai Saya</h3>
              <ul className="space-y-2 text-foreground/70">
                <li className="flex gap-2">
                  <span className="text-accent">✨</span>
                  <span>Autentisitas dan kejujuran dalam setiap interaksi</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">✨</span>
                  <span>Apresiasi terhadap keindahan dalam hal-hal sederhana</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">✨</span>
                  <span>Pertumbuhan berkelanjutan dan pembelajaran seumur hidup</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
