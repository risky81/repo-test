"use client"

import { useEffect, useRef, useState } from "react"
import { Play, Pause, SkipBack, SkipForward, Volume2 } from "lucide-react"
import { Card } from "@/components/ui/card"

interface Song {
  id: string
  title: string
  artist: string
  duration: number
  url: string
}

export default function MusicPlayer() {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [volume, setVolume] = useState(70)
  const [currentSongIndex, setCurrentSongIndex] = useState(0)

  const songs: Song[] = [
    {
      id: "1",
      title: "Kenangan Indah",
      artist: "Memories",
      duration: 212,
      url: "https://cdn.pixabay.com/download/audio/2022/11/18/audio_9a03d1b7b6.mp3?filename=memories-171566.mp3",
    },
    {
      id: "2",
      title: "Momen Bersama",
      artist: "Bensound",
      duration: 137,
      url: "https://cdn.pixabay.com/download/audio/2023/10/22/audio_8c0b9b8f2a.mp3?filename=acoustic-breeze-172914.mp3",
    },
    {
      id: "3",
      title: "Cinta dan Harapan",
      artist: "Ukulele Song",
      duration: 131,
      url: "https://cdn.pixabay.com/download/audio/2022/05/11/audio_8f2d5d1f7e.mp3?filename=ukulele-152528.mp3",
    },
    {
      id: "4",
      title: "Cerita Kita",
      artist: "Better Days",
      duration: 162,
      url: "https://cdn.pixabay.com/download/audio/2023/08/07/audio_6e2f3d5e5d.mp3?filename=better-days-169139.mp3",
    },
  ]

  const currentSong = songs[currentSongIndex]

  const togglePlay = () => {
    if (!audioRef.current) return

    if (isPlaying) {
      audioRef.current.pause()
      setIsPlaying(false)
    } else {
      audioRef.current.play().catch((err) => {
        console.log("[v0] Play error:", err)
        setIsPlaying(false)
      })
      setIsPlaying(true)
    }
  }

  const playSong = (index: number) => {
    if (!audioRef.current) return

    setCurrentSongIndex(index)
    setCurrentTime(0)

    // Tunggu sebentar agar src ter-update di DOM
    setTimeout(() => {
      if (audioRef.current) {
        audioRef.current.currentTime = 0
        audioRef.current.play().catch((err) => {
          console.log("[v0] Play error:", err)
          setIsPlaying(false)
        })
        setIsPlaying(true)
      }
    }, 50)
  }

  const handlePrevious = () => {
    playSong(currentSongIndex === 0 ? songs.length - 1 : currentSongIndex - 1)
  }

  const handleNext = () => {
    playSong(currentSongIndex === songs.length - 1 ? 0 : currentSongIndex + 1)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime)
    }

    const handleEnded = () => {
      handleNext()
    }

    audio.addEventListener("timeupdate", handleTimeUpdate)
    audio.addEventListener("ended", handleEnded)

    return () => {
      audio.removeEventListener("timeupdate", handleTimeUpdate)
      audio.removeEventListener("ended", handleEnded)
    }
  }, [currentSongIndex])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100
    }
  }, [volume])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.src = currentSong.url
    }
  }, [currentSongIndex, currentSong.url])

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-purple-950 via-black to-pink-950 flex items-center justify-center p-4">
      <Card className="max-w-md w-full bg-black/40 backdrop-blur-xl border-purple-500/30 shadow-2xl">
        <div className="p-8">
          {/* Visualizer */}
          <div className="flex items-end justify-center gap-1 h-24 mb-8">
            {[...Array(15)].map((_, i) => (
              <div
                key={i}
                className="w-1.5 bg-gradient-to-t from-purple-500 to-pink-500 rounded-full shadow-lg shadow-purple-500/50"
                style={{
                  height: isPlaying ? `${30 + Math.sin(Date.now() / 100 + i) * 40}px` : "20px",
                  animation: isPlaying ? `bounce ${0.8 + i * 0.08}s ease-in-out infinite alternate` : "none",
                }}
              />
            ))}
          </div>

          {/* Song Title */}
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-white mb-2">{currentSong.title}</h3>
            <p className="text-purple-300 text-sm">{currentSong.artist}</p>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden mb-3">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300 shadow-lg"
                style={{ width: `${(currentTime / currentSong.duration) * 100}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-purple-300">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(currentSong.duration)}</span>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-center gap-8 mb-10">
            <button onClick={handlePrevious} className="text-purple-300 hover:text-white transition">
              <SkipBack size={28} />
            </button>

            <button
              onClick={togglePlay}
              className="p-5 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full hover:scale-110 transition-all duration-300 shadow-xl hover:shadow-purple-500/50"
            >
              {isPlaying ? <Pause size={36} className="text-white" /> : <Play size={36} className="text-white ml-1" />}
            </button>

            <button onClick={handleNext} className="text-purple-300 hover:text-white transition">
              <SkipForward size={28} />
            </button>
          </div>

          {/* Volume Control */}
          <div className="flex items-center gap-4 mb-8">
            <Volume2 size={22} className="text-purple-300" />
            <input
              type="range"
              min="0"
              max="100"
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="flex-1 h-2 bg-white/20 rounded-full accent-purple-500 cursor-pointer"
            />
            <span className="text-purple-300 text-sm w-10 text-right">{volume}%</span>
          </div>

          {/* Playlist */}
          <div className="border-t border-purple-500/30 pt-6">
            <p className="text-purple-400 font-bold text-xs uppercase tracking-wider mb-4">Playlist</p>
            <div className="space-y-2">
              {songs.map((song, i) => (
                <button
                  key={song.id}
                  onClick={() => playSong(i)}
                  className={`w-full text-left p-4 rounded-xl transition-all ${
                    i === currentSongIndex
                      ? "bg-purple-600/40 text-white shadow-lg shadow-purple-500/30"
                      : "text-purple-300 hover:bg-white/5"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">{song.title}</p>
                      <p className="text-xs opacity-75">{song.artist}</p>
                    </div>
                    <span className="text-xs">{formatTime(song.duration)}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Audio Element */}
      <audio
        ref={audioRef}
        src={currentSong.url}
        preload="auto"
        crossOrigin="anonymous"
        onError={() => {
          console.log("[v0] Audio load error")
          setIsPlaying(false)
        }}
      />
    </div>
  )
}
