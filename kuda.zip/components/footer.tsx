"use client"

interface FooterProps {
  onNavigate: (section: string) => void
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-foreground/5 border-t border-border py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="font-semibold text-foreground mb-4">Navigasi</h3>
            <ul className="space-y-2">
              {[
                { label: "Beranda", id: "home" },
                { label: "Tentang", id: "about" },
                { label: "Galeri", id: "gallery" },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className="text-foreground/60 hover:text-primary transition-colors"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">Kontak</h3>
            <ul className="space-y-2 text-foreground/60">
              <li>Email: hello@example.com</li>
              <li>Telepon: +62 123 4567 8900</li>
              <li>Lokasi: Indonesia</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">Ikuti Saya</h3>
            <div className="flex gap-4">
              {[
                { name: "Instagram", icon: "📷" },
                { name: "Facebook", icon: "👤" },
                { name: "Twitter", icon: "🐦" },
              ].map((social) => (
                <a
                  key={social.name}
                  href="#"
                  className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary hover:bg-primary hover:text-primary-foreground transition-colors"
                  title={social.name}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-8">
          <p className="text-center text-foreground/50 text-sm">
            © 2025 Portfolio Pribadi. Dibuat dengan ❤️ menggunakan Next.js
          </p>
        </div>
      </div>
    </footer>
  )
}
