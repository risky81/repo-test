"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { ChevronRight, Heart } from "lucide-react"

interface Memory {
  id: string
  image: string
  date: string
  caption: string
  liked?: boolean
}

export default function MemoryGallery() {
  const [memories, setMemories] = useState<Memory[]>([
    {
      id: "1",
      image: "/gogo.jpg",
      date: "2024-11-10",
      caption: "okk..?",
      liked: false,
    },
    {
      id: "2",
      image: "/gege.jpg",
      date: "2024-11-05",
      caption: "wlee",
      liked: false,
    },
    {
      id: "3",
      image: "/gaga.jpg",
      date: "2024-10-28",
      caption: "y",
      liked: false,
    },
    {
      id: "4",
      image: "/gugu.jpg",
      date: "2024-10-15",
      caption: "hmzz",
      liked: false,
    },
  ])

  const [selectedMemory, setSelectedMemory] = useState<Memory | null>(null)

  const toggleLike = (id: string) => {
    setMemories(memories.map((mem) => (mem.id === id ? { ...mem, liked: !mem.liked } : mem)))
  }

  return (
    <div className="w-full">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="mb-8">
          <h2 className="text-4xl font-bold text-primary mb-2 text-balance">foto ak</h2>
          <p className="text-muted-foreground text-lg">ppk</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {memories.map((memory) => (
            <Card
              key={memory.id}
              className="overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer group"
              onClick={() => setSelectedMemory(memory)}
            >
              <div className="relative overflow-hidden bg-secondary h-64">
                <img
                  src={memory.image || "/placeholder.svg"}
                  alt={memory.caption}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <span className="text-white text-sm font-medium flex items-center gap-1">
                    Lihat Detail <ChevronRight size={16} />
                  </span>
                </div>
              </div>
              <div className="p-4">
                <p className="text-xs text-muted-foreground mb-2">{memory.date}</p>
                <p className="text-foreground font-medium mb-3">{memory.caption}</p>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleLike(memory.id)
                  }}
                  className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors"
                >
                  <Heart size={18} className={memory.liked ? "fill-accent text-accent" : ""} />
                  {memory.liked ? "Disimpan" : "Simpan"}
                </button>
              </div>
            </Card>
          ))}
        </div>

        {selectedMemory && (
          <div
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
            onClick={() => setSelectedMemory(null)}
          >
            <Card className="max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <button
                onClick={() => setSelectedMemory(null)}
                className="absolute top-4 right-4 text-foreground hover:text-primary transition-colors"
              >
                ✕
              </button>
              <img
                src={selectedMemory.image || "/placeholder.svg"}
                alt={selectedMemory.caption}
                className="w-full h-96 object-cover"
              />
              <div className="p-6">
                <p className="text-sm text-muted-foreground mb-2">{selectedMemory.date}</p>
                <h3 className="text-2xl font-bold text-primary mb-4">{selectedMemory.caption}</h3>
                <p className="text-foreground leading-relaxed mb-4">
                  manambggratisyangkaujanjikannitubwokkkk
                  pukipukipukipuki
                </p>
                <button
                  onClick={() => {
                    toggleLike(selectedMemory.id)
                    setSelectedMemory({
                      ...selectedMemory,
                      liked: !selectedMemory.liked,
                    })
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-opacity"
                >
                  <Heart size={20} className={selectedMemory.liked ? "fill-accent-foreground" : ""} />
                  {selectedMemory.liked ? "Disimpan" : "Simpan Kenangan"}
                </button>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
