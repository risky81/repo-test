"use client"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, ChevronDown, ChevronUp } from "lucide-react"

const songs = [
  {
    id: 1,
    title: "yellow",
    artist: "Wisp",
    url: "wispyellow.mp3",
  },
  {
    id: 2,
    title: "Lagu Kedua",
    artist: "Artis Anda",
    url: "/musik/lagu-2.mp3",
  },
  {
    id: 3,
    title: "Lagu Ketiga",
    artist: "Artis Anda",
    url: "/musik/lagu-3.mp3",
  },
]

export default function CuteMusicPlayer() {
  const [currentSongIndex, setCurrentSongIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const audioRef = useRef<HTMLAudioElement>(null)

  const currentSong = songs[currentSongIndex]

  const togglePlay = () => {
    if (!audioRef.current) return

    if (isPlaying) {
      audioRef.current.pause()
    } else {
      audioRef.current.play()
    }
    setIsPlaying(!isPlaying)
  }

  const handleSongChange = (index: number) => {
    setCurrentSongIndex(index)
    setCurrentTime(0)
    setIsExpanded(false)
  }

  const formatTime = (time: number) => {
    if (!time) return "0:00"
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const updateTime = () => setCurrentTime(audio.currentTime)
    const updateDuration = () => setDuration(audio.duration)
    const handleSongEnd = () => {
      setCurrentSongIndex((prev) => (prev + 1) % songs.length)
      setIsPlaying(true)
    }

    audio.addEventListener("timeupdate", updateTime)
    audio.addEventListener("loadedmetadata", updateDuration)
    audio.addEventListener("ended", handleSongEnd)

    return () => {
      audio.removeEventListener("timeupdate", updateTime)
      audio.removeEventListener("loadedmetadata", updateDuration)
      audio.removeEventListener("ended", handleSongEnd)
    }
  }, [])

  return (
    <section className="py-8 px-4">
      <div className="max-w-md mx-auto">
        <div className="bg-gradient-to-br from-pink-100/40 via-rose-100/30 to-pink-100/20 rounded-3xl p-6 border-2 border-pink-300/50 backdrop-blur-sm shadow-lg">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-pink-600">♪ My Music</h3>
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-2 hover:bg-pink-200/50 rounded-full transition-colors"
            >
              {isExpanded ? (
                <ChevronUp size={20} className="text-pink-600" />
              ) : (
                <ChevronDown size={20} className="text-pink-600" />
              )}
            </button>
          </div>

          {/* Now Playing */}
          <div className="text-center mb-6">
            <p className="text-sm text-pink-600/70 font-medium">{currentSong.artist}</p>
            <p className="text-xl font-bold text-pink-700">{currentSong.title}</p>
          </div>

          {/* Player Controls */}
          <div className="space-y-4">
            {/* Play Button */}
            <button
              onClick={togglePlay}
              className="w-full py-3 bg-gradient-to-r from-pink-400 to-rose-400 hover:from-pink-500 hover:to-rose-500 rounded-full text-white font-bold flex items-center justify-center gap-2 transition-all shadow-md"
            >
              {isPlaying ? (
                <>
                  <Pause size={20} /> Pause
                </>
              ) : (
                <>
                  <Play size={20} /> Play
                </>
              )}
            </button>

            {/* Progress Bar */}
            <div className="space-y-1">
              <input
                type="range"
                min="0"
                max={duration || 0}
                value={currentTime}
                onChange={(e) => {
                  const time = Number.parseFloat(e.target.value)
                  setCurrentTime(time)
                  if (audioRef.current) {
                    audioRef.current.currentTime = time
                  }
                }}
                className="w-full h-2 bg-pink-200/50 rounded-full appearance-none cursor-pointer accent-pink-500"
              />
              <div className="flex justify-between text-xs text-pink-600/70">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>
          </div>

          {/* Playlist */}
          {isExpanded && (
            <div className="space-y-2 border-t border-pink-300/40 pt-4 mt-4">
              {songs.map((song, index) => (
                <button
                  key={song.id}
                  onClick={() => handleSongChange(index)}
                  className={`w-full p-3 rounded-xl text-left transition-all ${
                    currentSongIndex === index
                      ? "bg-pink-300/50 border-2 border-pink-400"
                      : "bg-pink-100/40 border-2 border-transparent hover:bg-pink-200/40"
                  }`}
                >
                  <p className="font-semibold text-sm text-pink-700">{song.title}</p>
                  <p className="text-xs text-pink-600/70">{song.artist}</p>
                </button>
              ))}
            </div>
          )}

          {/* Decorative dots */}
          <div className="flex justify-center gap-2 mt-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="w-1 h-2 rounded-full bg-pink-300/50" />
            ))}
          </div>
        </div>
      </div>

      {/* Hidden audio element */}
      <audio ref={audioRef} src={currentSong.url} />
    </section>
  )
}
