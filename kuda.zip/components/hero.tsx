"use client"

export default function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center pt-20 px-4 bg-gradient-to-br from-background via-background to-secondary/20">
      <div className="max-w-4xl text-center">
        <div className="mb-8">
          <div className="w-32 h-32 mx-auto mb-8 rounded-full bg-primary/10 border-4 border-primary/20 flex items-center justify-center overflow-hidden">
            <img src="/professional-portrait.jpg" alt="Profil" className="w-full h-full object-cover" />
          </div>
        </div>
        <h1 className="text-5xl sm:text-6xl font-bold text-foreground mb-4 text-pretty">Selamat Datang</h1>
        <p className="text-lg sm:text-xl text-foreground/70 mb-8 text-pretty max-w-2xl mx-auto">
          Ini adalah ruang pribadi saya untuk berbagi cerita, pengalaman, dan momen berharga melalui foto
        </p>
        <button
          onClick={() => {
            document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })
          }}
          className="px-8 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-accent transition-colors"
        >
          Pelajari Lebih Lanjut
        </button>
      </div>
    </section>
  )
}
