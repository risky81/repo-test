"use client"

import { useState } from "react"

const GALLERY_ITEMS = [
  {
    id: 1,
    title: "Sunset Moment",
    category: "Landscape",
    image: "/beautiful-sunset-landscape.jpg",
  },
  {
    id: 2,
    title: "Urban Adventure",
    category: "Travel",
    image: "/urban-city-photography.jpg",
  },
  {
    id: 3,
    title: "Nature Close-up",
    category: "Nature",
    image: "/nature-macro-photography.jpg",
  },
  {
    id: 4,
    title: "Mountain View",
    category: "Landscape",
    image: "/mountain-peak-scenery.jpg",
  },
  {
    id: 5,
    title: "Street Photography",
    category: "Travel",
    image: "/street-photography-candid.jpg",
  },
  {
    id: 6,
    title: "Flower Garden",
    category: "Nature",
    image: "/colorful-flowers-garden.jpg",
  },
]

const CATEGORIES = ["Semua", "Landscape", "Travel", "Nature"]

export default function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState("Semua")
  const [selectedImage, setSelectedImage] = useState<(typeof GALLERY_ITEMS)[0] | null>(null)

  const filteredItems =
    selectedCategory === "Semua" ? GALLERY_ITEMS : GALLERY_ITEMS.filter((item) => item.category === selectedCategory)

  return (
    <section className="py-20 px-4 bg-secondary/30">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl sm:text-5xl font-bold text-foreground mb-4 text-balance">Galeri Foto</h2>
        <p className="text-foreground/60 mb-12 text-lg">Koleksi momen berharga dari perjalanan saya</p>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-3 mb-12">
          {CATEGORIES.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                selectedCategory === category
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground border border-border hover:border-primary/50"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedImage(item)}
              className="group cursor-pointer overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <div className="relative h-72 bg-muted overflow-hidden">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-end">
                  <div className="w-full p-4 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="font-semibold text-lg">{item.title}</h3>
                    <p className="text-sm text-white/80">{item.category}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {selectedImage && (
          <div
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
            onClick={() => setSelectedImage(null)}
          >
            <div className="relative max-w-3xl w-full" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute -top-10 right-0 text-white hover:text-accent transition-colors"
              >
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
              <img
                src={selectedImage.image || "/placeholder.svg"}
                alt={selectedImage.title}
                className="w-full rounded-lg"
              />
              <div className="mt-4 text-white">
                <h3 className="text-2xl font-semibold">{selectedImage.title}</h3>
                <p className="text-white/70">{selectedImage.category}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
