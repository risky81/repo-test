# Folder Musik

Tempat untuk menyimpan file MP3 musik Anda.

## Cara menggunakan:

1. Upload file MP3 Anda ke folder ini
2. Sesuaikan nama file di `components/cute-music-player.tsx`

### Contoh:
- Jika file bernama `lagu-1.mp3`, gunakan: `/musik/lagu-1.mp3`
- Jika file bernama `favorite.mp3`, gunakan: `/musik/favorite.mp3`

Setiap file MP3 yang ada di folder ini akan bisa diakses di music player.
