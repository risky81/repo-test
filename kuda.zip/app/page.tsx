"use client"
import MemoryGallery from "@/components/memory-gallery"
import MemoryUpload from "@/components/memory-upload"
import SanrioCharacters from "@/components/sanrio-characters"
import AffirmationQuotes from "@/components/affirmation-quotes"
import CuteMusicPlayer from "@/components/cute-music-player"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      <SanrioCharacters />

      {/* Main content */}
      <div className="relative z-10">
        {/* Hero section */}
        <section className="py-16 px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-primary mb-4 text-balance">Hello World</h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              hi gusy selamat datang di web aku. (isinya foto foto doang jir) tapi yauda lah y, yang penting imup
            </p>
          </div>
        </section>

        {/* Affirmation quotes section */}
        <AffirmationQuotes />

        {/* Music player section */}
        <CuteMusicPlayer />

        {/* Gallery section */}
        <section className="py-12">
          <MemoryGallery />
        </section>

        {/* Footer */}
        <footer className="py-8 px-4 border-t border-border/30 backdrop-blur-sm">
          <div className="max-w-4xl mx-auto text-center text-muted-foreground">
            <p>sudah segitu aja y gusy, ini cuma buat nyimpen foto doang</p>
            <p className="text-sm mt-2">Terima kasih, sampai jumpa</p>
          </div>
        </footer>
      </div>

      {/* Upload modal */}
      <MemoryUpload />
    </div>
  )
}
